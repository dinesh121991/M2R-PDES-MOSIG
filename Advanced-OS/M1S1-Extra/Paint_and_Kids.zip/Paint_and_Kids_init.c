#include <stdlib.h>
#include "Paint_and_Kids.h"

void initialize_shared_data(int C, int B, int *P, int n, struct shared_data *data) {
	int i,j;

	data->C = C;
	data->B = B;
	data->n = n;
	data->available_brushes = B;
	// Children are numbered from 1 to C, positions range from 0 (left of first child)
	// to C (right of last child)
	data->shared_pots = malloc(sizeof(struct shared_pot *)*(C+1));
	for (i=0; i<=C; i++) {
		// Colors are numbered from 1 to n, we don't use the index 0
		data->shared_pots[i] = malloc(sizeof(struct shared_pot)*(n+1));
		for (j=1; j<=n; j++) {
			data->shared_pots[i][j].present = 0;
			data->shared_pots[i][j].left_use = 0;
			data->shared_pots[i][j].right_use = 0;
		}
	}
	// Colors are numbered from 1 to n, we don't use the index 0
	data->available_pots = malloc(sizeof(int)*(n+1));
	for (j=1; j<=n; j++)
		data->available_pots[j] = P[j];

	pthread_mutex_init(&data->lock, NULL);
	pthread_cond_init(&data->brush_available, NULL);
	data->pot_available = malloc(sizeof(pthread_cond_t)*(n+1));
	for (j=1; j<=n; j++)
		pthread_cond_init(&data->pot_available[j], NULL);
}
