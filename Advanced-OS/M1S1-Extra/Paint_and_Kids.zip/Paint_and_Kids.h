#include <pthread.h>

// structure to modelize the state of a shared pot
struct shared_pot {
	int present, left_use, right_use;
};

struct shared_data {
	int C, B, n;
	int available_brushes;
	// state of shared pots (for each position and each color)
	struct shared_pot **shared_pots;
	int *available_pots;   // pots availability (for each color)

	// monitor lock
	pthread_mutex_t lock;
	// condition variables associated to brushes and pots (for each color)
	// a simpler solution would be to have only one condition variable
	pthread_cond_t brush_available;
	pthread_cond_t *pot_available;
};
