#include <stdlib.h>
#include <stdio.h>
#include "Paint_and_Kids.h"
#include "Paint_and_Kids_threads.h"

int allocate_brush(struct shared_data *s, int number) {
	pthread_mutex_lock(&s->lock);
	while (!s->available_brushes) {
		printf("No brush available child %d started waiting\n", number);
		pthread_cond_wait(&s->brush_available, &s->lock);
	}
	s->available_brushes--;
	printf("Allocated one brush to child %d\n", number);
	pthread_mutex_unlock(&s->lock);
	return 1;
}

void free_brush(struct shared_data *s, int number) {
	pthread_mutex_lock(&s->lock);
	s->available_brushes++;
	pthread_cond_signal(&s->brush_available);
	printf("Child %d freed one brush\n", number);
	pthread_mutex_unlock(&s->lock);
}

int allocate_pot(struct shared_data *s, int number, int color) {
	int result;
	pthread_mutex_lock(&s->lock);
	// If a pot of the same color is already in use, do nothing
	if (!s->shared_pots[number-1][color].right_use &&
	    !s->shared_pots[number][color].left_use) {
		// If a pot is already present, use it
		if (s->shared_pots[number-1][color].present) {
			s->shared_pots[number-1][color].right_use = 1;
			printf("Child %d started to use pot of %d paint on its left\n", number, color);
		} else if (s->shared_pots[number][color].present) {
			s->shared_pots[number][color].left_use = 1;
			printf("Child %d started to use pot of %d paint on its right\n", number, color);
		} else {
			// Otherwise allocate a new one and place it on the right
			// (this is an arbitrary choice)
			while (!s->available_pots[color]) {
				printf("No %d paint available child %d started waiting\n", color, number);
				pthread_cond_wait(&s->pot_available[color], &s->lock);
			}
			s->shared_pots[number][color].present = 1;
			s->shared_pots[number][color].left_use = 1;
			s->available_pots[color]--;
			printf("Allocated one pot of %d paint to child %d on its right\n", color, number);
		}
		result = 1;
	} else {
		printf("Ignored request from child %d who already has access to a pot of %d paint\n", number, color);
		result = 0;
	}
	print_shared_state(s);
	pthread_mutex_unlock(&s->lock);
	return result;
}

void free_pot(struct shared_data *s, int number, int color) {
	struct shared_pot *pot = NULL;
	pthread_mutex_lock(&s->lock);
	if (s->shared_pots[number-1][color].right_use) {
		pot = &s->shared_pots[number-1][color];
		pot->right_use = 0;
		printf("Child %d has stoped using the pot of %d paint on its left\n", number, color);
	}
	if (s->shared_pots[number][color].left_use) {
		pot = &s->shared_pots[number][color];
		pot->left_use = 0;
		printf("Child %d has stoped using the pot of %d paint on its right\n", number, color);
	}
	if (!pot->left_use && !pot->right_use) {
		pot->present = 0;
		s->available_pots[color]++;
		pthread_cond_signal(&s->pot_available[color]);
		printf("A pot of %d paint has been freed\n", color);
	}
	print_shared_state(s);
	pthread_mutex_unlock(&s->lock);
}

void *child_behavior(void *arg) {
	int i;
	struct thread_data *t = (struct thread_data *) arg;
	struct shared_data *s = t->shared;

	int allocated_brushes = 0;
	int *allocated_pots = malloc(sizeof(int)*(s->n+1));
	for (i=0; i<=s->n; i++)
		allocated_pots[i] = 0;
	int total_allocated = 0;

	srandom((unsigned) (intptr_t) pthread_self());
	for (i=0; (i<t->iterations) || total_allocated; i++) {
		// allocate or free ?
		if ((i<t->iterations) && (random()%2)) {
			// brush or pot of paint ?
			if (random()%2) {
				// We avoid allocating several brushes to minimize deadlocks frequency
				if (!allocated_brushes) {
					if (allocate_brush(s, t->number)) {
						allocated_brushes++;
						total_allocated++;
					}
				}
			} else {
				int color = random()%s->n + 1;
				if (allocate_pot(s, t->number, color)) {
					allocated_pots[color]++;
					total_allocated++;
				}
			}
		} else {
			// brush or pot of paint ?
			if (random()%2) {
				if (allocated_brushes) {
					free_brush(s, t->number);
					allocated_brushes--;
					total_allocated--;
				}
			} else {
				int color = random()%s->n + 1;
				if (allocated_pots[color]) {
					free_pot(s, t->number, color);
					allocated_pots[color]--;
					total_allocated--;
				}
			}
		}
	}
	pthread_exit(NULL);
}
