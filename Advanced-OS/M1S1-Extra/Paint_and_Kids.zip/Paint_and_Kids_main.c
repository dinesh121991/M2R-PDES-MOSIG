#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Paint_and_Kids.h"
#include "Paint_and_Kids_threads.h"

void print_shared_state(struct shared_data *s) {
	int i, j;

	for (j=1; j<=s->n; j++) {
		for (i=0; i<=s->C; i++) {
			if (s->shared_pots[i][j].left_use)
				printf("-");
			else
				printf(" ");
			if (s->shared_pots[i][j].present)
				printf("U");
			else
				printf(" ");
			if (s->shared_pots[i][j].right_use)
				printf("-");
			else
				printf(" ");
			if (i<s->C)
				switch (j) {
				case 1:
					printf(" O ");
					break;
				case 2:
					printf("/|\\");
					break;
				case 3:
					printf("/ \\");
					break;
				default:
					printf("   ");
				}
		}
		printf("\n");
	}
}

int main(int argc, char *argv[]) {
    struct thread_data *data;
    struct shared_data shared;
    pthread_t *tids;
    int result, i;
    int C, B, n, iterations;
    int *P;

    if (argc < 5) {
        fprintf(stderr,
                "Usage:\n"
		"%s iterations C B P1 ... Pn\n\n"
		"where :\n"
		"C is the number of children\n"
		"B is the number of brushes\n"
		"P1 ... Pn are the number of pots for each color\n"
		, argv[0]);
        exit(1);
    }

    iterations = atoi(argv[1]);
    C = atoi(argv[2]);
    B = atoi(argv[3]);
    n = argc - 4;
    P = malloc(sizeof(int)*(n+1));
    for (i=1; i<=n; i++)
	    P[i] = atoi(argv[i+3]);

    initialize_shared_data(C, B, P, n, &shared);

    /* allocation of threads data */
    data = malloc (C*sizeof(struct thread_data));
    for (i=0; i<C; i++) {
        data[i].number = i+1;
	data[i].iterations = iterations;
        data[i].shared = &shared;
    }
    
    /* creation of threads */
    tids = (pthread_t *) malloc(C*sizeof(pthread_t));
    result = 0;
    for (i=0; (result == 0) && (i<C); i++) {
        result = result ||
            pthread_create(&tids[i], NULL, child_behavior, &data[i]);
    }
    if (result) {
        fprintf(stderr, "Erreur de création d'un des threads\n");
        exit(1);
    }

    /* wait for termination of threads */
    for (i=0; i<C; i++) {
        pthread_join(tids[i], NULL);
    }
    return 0;
}
