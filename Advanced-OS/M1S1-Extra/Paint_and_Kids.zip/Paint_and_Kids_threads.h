struct thread_data {
    int number, iterations;
    struct shared_data *shared;
};

void initialize_shared_data(int C, int B, int *P, int n, struct shared_data *data);
void *child_behavior(void *arg);
void print_shared_state(struct shared_data *data);
