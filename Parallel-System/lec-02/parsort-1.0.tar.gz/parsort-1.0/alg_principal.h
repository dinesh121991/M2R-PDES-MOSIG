#ifndef __INTERFACE_RECHERCHE__
#define __INTERFACE_RECHERCHE__

void call_sort(int parallelism, int *vector, int size, char *arg);

#endif
